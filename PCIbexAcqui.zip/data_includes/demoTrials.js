let animateWheel = level=>[
    getTimer("eraseGuide").start()
    ,
    getCanvas("wheel").setWheel( level , DELAYWHEEL)
    ,
    getTimer("eraseGuide").test.running().success( getTimer("eraseGuide").wait() )
    ,
    newTimer(500).start().wait()
]

PennController.Template(    // We filter the table because we only want one demo trial per item
  PennController.GetTable("wheels").filter( row=>row.Form=="comparative"&&row.Force=="mid" ) 
  ,
  row => PennController(    "demo-"+row.Item ,
    ...createWheel(row)
    ,
    getCanvas("wheel").setWheel(0)      // Making sure the wheel is at 0
    ,
    newTimer("eraseGuide", 1500).settings.callback( getTooltip("guide").remove() )      // Creation of timer, but not called yet
    ,
    newTimer(500).start().wait()
    ,    
    getTooltip("guide")
        .settings.position("bottom center")
        .settings.text("See the knob here? We can use it to control the "+row.Dimension+".")
        .print( getCanvas("anchorWheel") )
        .wait()
        .settings.text("We can move it like this, and the "+row.Dimension+" goes up...")
        .settings.label("")
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( 9 )
    ,
    getTooltip("guide")
        .settings.text("We can move it like this, and the "+row.Dimension+" goes down...")
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( 0 )
    ,
    getTooltip("guide")
        .settings.text("When it is here, the "+row.Dimension+" is "+row.MinAdj.toUpperCase())
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( Number(row.MinLevel) )
    ,
    getTooltip("guide")
        .settings.text("When it is here, the "+row.Dimension+" is "+row.MaxAdj.toUpperCase())
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( Number(row.MaxLevel) )
    ,
    getTooltip("guide")
        .settings.text("And when it is here, it is "+row.MidAdj.toUpperCase())
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( Number(row.MidLevel) )
    ,
    getTooltip("guide")
        .settings.label("Press Space")
        .settings.text("Got it? Let's do it one more time")
        .print( getCanvas("anchorWheel") )
        .wait()
        .settings.label("")
        .settings.text("Here it is "+row.MinAdj.toUpperCase()+"...")
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( Number(row.MinLevel) )
    ,
    getTooltip("guide")
        .settings.text("Here it is "+row.MaxAdj.toUpperCase()+"...")
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( Number(row.MaxLevel) )
    ,
    getTooltip("guide")
        .settings.text("And here it is "+row.MidAdj.toUpperCase())
        .print( getCanvas("anchorWheel") )
    ,
    ...animateWheel( Number(row.MidLevel) )
    ,
    getTooltip("guide")
        .settings.label("Press Space")
        .settings.text("So, we can make the "+row.Dimension+" "+row.MinAdj.toUpperCase()+", "+row.MidAdj.toUpperCase()+" or "+row.MaxAdj.toUpperCase())
        .print( getCanvas("anchorWheel") )
        .wait()
    ,
    newTimer(500).start().wait()
    ,
    getCanvas("container").remove()
    ,
    getTooltip("guide")
        .settings.text("Great. Now, my friends have their preferences...")
        //.print( getCanvas("anchorWheel") )
        .print(  )
        .wait()
    ,
    newTimer(250).start().wait()
  )
  .log("id", PennController.GetURLParameter("id"))
);