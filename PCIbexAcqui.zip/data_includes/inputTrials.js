// We will need this to check whether the wheel was actually set to a new value (see below)
let previousLevel = -1;

PennController.Template( 
  "wheels"      // Unfiltered table: we generate as many input trials as there are rows (i.e. conditions)
  ,
  row => PennController(    "input-" + row.Item ,
    newTimer(250)
        .start()
        .wait()
    ,
    newImage( "animal" , row.Animal + ".png" )
        .settings.size( "200px" , "auto" )
        .print( "center at 50%" , "center at 50%" )
    ,
    getTooltip("guide")
        .settings.position("top center")
        .settings.text( row.Name+" is here!")
        .print( getImage("animal") )
        .wait()
    ,
    ...createWheel(row)
    ,
    getCanvas("container")
        .settings.visible()
    ,
    getCanvas("wheel")
        .setWheel( Number(row.Level) )
        .settings.add( "center at 50%" , "center at -2.5%" , getImage("animal").settings.size("100px","auto").settings.cssContainer("z-index",-1) )
    ,
    getTooltip("guide")
        .settings.position("bottom center")
        .settings.text( row.SentenceArrival )
        .print( getCanvas("anchorWheel") )
        .wait()
        .settings.text( row.SentenceDislike )
        .print( getCanvas("anchorWheel") )
        .wait()
        .settings.text( row.SentenceInstructions )
        .settings.label("Move the knob")
        .settings.disable()
        .print( getCanvas("anchorWheel") )
    ,
    newTimer("moveKnob", 250)
    ,
    getCanvas("wheel")
        .settings.enableWheel()
        .settings.callbackWheel( l=>{ 
            if (previousLevel != l) {
                previousLevel = l; 
                getScale("levels").select(l,"log")._runPromises();
                getTimer("moveKnob").start()._runPromises();
            } 
        })
    ,
    getTimer("moveKnob")
        .wait()
    ,
    getTooltip("guide")
        .settings.label("")
        .settings.text("Click the button below when you are done moving the knob")
        .print( getCanvas("anchorWheel") )
    ,
    newButton("done", "I set the knob")
        .settings.cssContainer("margin-top","1em")
        .settings.center()
        .print()
        .wait()
        .remove()
    ,
    getCanvas("wheel")
        .settings.disableWheel()
    ,
    getTooltip("guide")
        .settings.enable()
        .settings.label("Press Space")
        .settings.text( row.SentenceCompletion )
        .print( getCanvas("anchorWheel") )
        .wait()
    ,
    newTimer(250)
        .start()
        .wait()
  )
  .log("id", PennController.GetURLParameter("id"))
  .log("Form", row.Form)
  .log("Force", row.Force)
  .log("Level", row.Level)
  .log("Tested", row.Tested)
  .setOption("hideProgressBar",true)
);