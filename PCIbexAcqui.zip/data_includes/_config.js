PennController.ResetPrefix(null);

// Canvas' dimensions
let WIDTH = 500,
    HEIGHT = 500;

// The delay (in ms) between each frame when moving the wheel in demo
let DELAYWHEEL = 250;

// The table comes from a distant Google spreadsheet
PennController.AddTable( "wheels" , "https://docs.google.com/spreadsheets/d/e/2PACX-1vRV-gCshnAOJzy-eiNVLiChYkBxtDf_poyiomkbjDdYsuOwJ2KfNivMQh0AUzKqbOH8_DjE39Z6aSC7/pub?gid=0&single=true&output=csv" )

// Where the resources are stored (temporary)
PennController.AddHost("https://raw.githubusercontent.com/Kitai/Acqui/master/")

// The guide is common to all trials
PennController.Header(
    newTooltip("guide", "", "Press Space")
        .settings.key(" ", "no click")
        .settings.size( WIDTH/2.5 , "auto" )
        .settings.position("middle center")
);

PennController.Sequence( 
    "instructions"
    ,   
    "intro" 
    , 
    "demo-Bathtub" , randomize("input-Bathtub") 
    , 
    "demo-Lamp" , randomize("input-Lamp") 
    ,
    "demo-Clock" , randomize("input-Clock")
    ,
    "demo-Bed" , randomize("input-Bed")
    ,
    "feedback"
    ,
    "send"
    ,
    "confirmation"
)