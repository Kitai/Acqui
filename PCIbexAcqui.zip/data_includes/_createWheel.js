createWheel = row => [
    defaultImage
        .settings.size(WIDTH,HEIGHT)
    ,
    newScale("levels", 10)
        .settings.log("all")
    ,
    newTimer(250)
        .start()
        .wait()
    ,
    newCanvas("container", WIDTH,HEIGHT)
        .settings.css("background","lightgray")
        .settings.add( 0 , 0 , newImage(row.Pic1).settings.asWheelLevel(0) )
        .settings.add( 0 , 0 , newImage(row.Pic2).settings.asWheelLevel(1) )
        .settings.add( 0 , 0 , newImage(row.Pic3).settings.asWheelLevel(2) )
        .settings.add( 0 , 0 , newImage(row.Pic4).settings.asWheelLevel(3) )
        .settings.add( 0 , 0 , newImage(row.Pic5).settings.asWheelLevel(4) )
        .settings.add( 0 , 0 , newImage(row.Pic6).settings.asWheelLevel(5) )
        .settings.add( 0 , 0 , newImage(row.Pic7).settings.asWheelLevel(6) )
        .settings.add( 0 , 0 , newImage(row.Pic8).settings.asWheelLevel(7) )
        .settings.add( 0 , 0 , newImage(row.Pic9).settings.asWheelLevel(8) )
        .settings.add( 0 , 0 , newImage(row.Pic10).settings.asWheelLevel(9) )
        .settings.add( 0 , 0 , newCanvas("wheel", WIDTH,HEIGHT) )
        .settings.add( WIDTH*row.AnchorX/row.Width,HEIGHT*row.AnchorY/row.Height , newCanvas("anchorWheel",1,1) )
        .print()
    ,
    getCanvas("wheel")
        .asWheel(WIDTH*row.CenterX/row.Width,HEIGHT*row.CenterY/row.Height)
        .settings.disableWheel()
    ,
    ..._itemSpecific(row)
];