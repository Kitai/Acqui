// Practice knob
PennController(
    "instructions"
    ,
    getTooltip("guide")
        .settings.text("Welcome")
        .print( "center at 50%" , "center at 50%" )
        .wait()
    ,
    ...createWheel({
        Pic1: "knob1.png" , Pic2: "knob2.png" , Pic3: "knob3.png" , Pic4: "knob4.png" , Pic5: "knob5.png" ,
        Pic6: "knob6.png" , Pic7: "knob7.png" , Pic8: "knob8.png" , Pic9: "knob9.png" , Pic10: "knob10.png" ,
        CenterX: 490, CenterY: 580, AnchorX: 475, AnchorY: 700, Width: 955, Height: 955
    })
    ,
    getCanvas("wheel")
        .setWheel(0)
    ,
    getTooltip("guide")
        .settings.text("In this experiment, you will be invited to use a knob, like the one displayed here")
        .print( getCanvas("anchorWheel") )
        .wait()
        .settings.text("To move the knob, click and drag it, as you would if you were moving a file around")
        .print( getCanvas("anchorWheel") )
        .wait()
    ,
    newTimer("moveWheel", 250)
    ,
    getCanvas("wheel")
        .settings.callbackWheel( ()=>getTimer("moveWheel").start()._runPromises() )
        .settings.enableWheel()
    ,
    getTimer("moveWheel")
        .wait()
    ,
    getTooltip("guide")
        .settings.text("Some touchscreens also allow you to directly move it manually")
        .print( getCanvas("anchorWheel") )
        .wait()
    , 
    newButton("done", "I moved the knob")
        .settings.cssContainer("margin-top","1em")
        .settings.center()
        .print()
    ,
    getTooltip("guide")
        .settings.label("")
        .settings.text("Click the button below when you are done with practicing moving the knob")
        .print( getCanvas("anchorWheel") )
    ,
    getButton("done")
        .wait()
)
.log("id", PennController.GetURLParameter("id"))



// Caveat / notes
PennController(
    "instructions"
    ,
    newText(
        `<p>A few caveats before we start the experiment: <ul>
        
        <li>This experiment was designed for children, so you will be spoken to you as such.</li>
        
        <li>This is NOT an evaluation: there is no right answer to guess. We are interested in your intuitions (and in the children's intuitions)
        regardless of how other people might approach this task.</li>
        
        <li>You might see words that you are not familiar with in this experiment. If so, just complete the task in the way that makes the most sense to you.</li>
        
        <li>Some parts of this experiment use sound effects. Although you can still complete the experiment with your sound turned off, 
        please consider turning it on to ensure optimal experimental conditions.</li>
        
        </ul>
        
        When you are ready to start the experiment, click the button below.</p>
    `)
        .settings.css("max-width", "50em")
        .print()
    ,
    newButton("Start the experiment")
        .settings.center()
        .print()
        .wait()
)
.log("id", PennController.GetURLParameter("id"))



// Post-experiment feedback page
PennController(
    "feedback"
    ,
    defaultText
        .settings.css("max-width", "50em")
    ,
    newText("<p>You are almost done: a confirmation link will appear on the next screen.</p>")
        .settings.bold()
        .print()
    ,
    newText("<p>Please, let us know if you turned the sound on during this experiment. Use the box below if you have any additional comments.</p>")
        .print()
    ,
    newText("warning", "Please select an option")
        .settings.color("red")
        .print()
        .settings.hidden()
    ,
    newScale("sound", "on", "off")
        .settings.log()
        .settings.labelsPosition("right")
        .settings.before( newText("My sound was") )
        .settings.callback( getText("warning").settings.hidden() )
        .print()
    ,
    newText("Comments:")
        .settings.bold()
        .settings.cssContainer("margin-top","1em")
        .print()
    ,
    newTextInput("feedback", "")
        .settings.lines(0)
        .settings.log()
        .print()
    ,
    newButton("Send my submission and show my confirmation link")
        .settings.center()
        .print()
        .wait(
            getScale("sound").test.selected()
                .failure( getText("warning").settings.visible() )
        )
)
.log("id", PennController.GetURLParameter("id"))



// Send results
PennController.SendResults("send")



// Confirmation page
PennController(
    "confirmation"
    ,
    defaultText
        .settings.css("max-width", "50em")
        .settings.center()
    ,
    newText("Your submission has been sent successfully!")
        .settings.color("green")
        .print()
    ,
    newText("<p><a href='' target='_blank'>Click here to validate your participation and receive your credit</a></p>")
        .settings.bold()
        .settings.css("font-size", "2em")
        .print()
    ,
    newTimer(1).wait()
)
.setOption("countsForProgressBar",false)
// .setOption("hideProgressBar",true)