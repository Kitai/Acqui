(function(){
    
    let STEPS = [Math.PI,2.76,2.40,2.04,1.73,1.42,1.11,0.75,0.39,0];
    
    let centerX, centerY;
    let wheel;
    let level = 0;
    let levelImages = [];
    let callbacks = [];
    let cursorRad;
    let enabled = true;
    
    function setWheel(l) {
        l = Number(l);
        if (isNaN(l) || l < 0 || l >= levelImages.length)
            return;
        let oldLevel = level;
        level = l;
        if (oldLevel != level){
            if (level >= 0 && level < levelImages.length)
                PennController.Elements['get'+levelImages[level].type](levelImages[level].id).settings.visible()._runPromises();
            if (oldLevel >= 0 && oldLevel < levelImages.length)
                PennController.Elements['get'+levelImages[oldLevel].type](levelImages[oldLevel].id).settings.hidden()._runPromises();
        }
        callbacks.map(v=>{
            if (v instanceof Function)
                v.call(null,level);
            else if (v._runPromises && v._runPromises instanceof Function)
                v._runPromises();
        });
    }
    
    function newWheel(){
        callbacks = [];
        let previousX = 0, previousY = 0;
        let previousRadDiff = 0;
        let clicking = false;
        level = 0;
        cursorRad = Math.PI;
        getClosest = function(ar, value){
            let va = Number(value);
            if (isNaN(va))
                return NaN;
            let a = ar.filter(v=>!isNaN(Number(v)));            
            if (a.length===0)
                return NaN;
            let diff = Math.max(...a.map(v=>Math.abs(va-Number(v)))), n = 0;
            for (let i = 0; i < a.length; i++){
                let d = Math.abs(va-Number(a[i]));
                if (d <= diff){
                    diff = d;
                    n = i;
                }
            }
            return {angle: a[n], index: n};
        };
        let complementRad = function(rad){
            if (rad > 0)
                return rad - 2*Math.PI;
            else if (rad < 0)
                return 2*Math.PI + rad;
            else
                return 0;
        };
        let update = function(e){
            let dims = wheel.getBoundingClientRect();
            let cX = centerX + dims.left, cY = centerY + dims.top;
            let xTo = e.clientX - cX,
                yTo = e.clientY - cY;
            let xFrom = previousX - cX,
                yFrom = previousY - cY;
            let radTo = Math.atan2(yTo,xTo);
            let radFrom = Math.atan2(yFrom,xFrom);
            let radDiff = radTo - radFrom;
            if ((radDiff > Math.PI && previousRadDiff <= 0) || (radDiff < -1*Math.PI && previousRadDiff >= 0))
                radDiff = complementRad(radTo) - radFrom;
            previousRadDiff = radDiff;
            cursorRad -= radDiff;
            if (cursorRad < 0)
                cursorRad = 0;
            else if (cursorRad > Math.PI)
                cursorRad = Math.PI;
            let visualRad = getClosest(STEPS, cursorRad);
            setWheel(visualRad.index);
            previousX = e.clientX;
            previousY = e.clientY;
        };
        document.body.onmousemove = function(e){
            if (clicking)
                update(e);
        };
        document.onmouseup = function(){
            clicking = false;
            cursorRad = getClosest(STEPS, cursorRad).angle;
        };
        wheel.onmousedown = function(e){
            if (!enabled) return;
            clicking = true;
            previousX = e.clientX;
            previousY = e.clientY;
        };
        levelImages.map(level=>{
            if (level && level.type)
                PennController.Elements['get'+level.type](level.id).settings.hidden()._runPromises();
        });
        if (levelImages.length && levelImages[0] && levelImages[0].type)
            PennController.Elements['get'+levelImages[0].type](levelImages[0].id).settings.visible()._runPromises();
    }
    
    window.PennController._AddStandardCommands(function(PennEngine){
        this.actions = {
            asWheel: function(resolve, x, y){
                centerX = x;
                centerY = y;
                wheel = this.jQueryContainer[0];
                newWheel();
                this.jQueryContainer.css("cursor","move");
                resolve();
            }
            ,
            setWheel: async function(resolve, l, delay){
                if (delay && Number(delay) > 0 && l != level && Number(l) >= 0 && Number(l) < levelImages.length){
                    let step = 1 - 2*(level > l);
                    setWheel(level+step);
                    for (let n = level+step; n != l+step; n += step)
                        await new Promise(r=>setTimeout(()=>{ setWheel(n); r(); },delay));
                    cursorRad = STEPS[level];
                    resolve();
                }
                else{
                    setWheel(l);
                    cursorRad = STEPS[level];
                    resolve();
                }
            }
        };
        this.settings = {
            asWheelLevel: function(resolve, n) {
                levelImages[n] = this;
                resolve();
            }
            ,
            callbackWheel: function(resolve, f){
                callbacks.push(f);
                resolve();
            }
            ,
            enableWheel: function(resolve){
                enabled = true;
                this.jQueryContainer.css("cursor","move");
                resolve();
            }
            ,
            disableWheel: function(resolve){
                enabled = false;
                this.jQueryContainer.css("cursor","initial");
                resolve();
            }
        };
    });
    
})();