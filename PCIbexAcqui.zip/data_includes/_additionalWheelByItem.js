function _itemSpecific(row){
    switch(row.Item){
        case "Bathtub":
            return [
                newAudio( "backgroundSound" , row.Pic1.replace("1.png",".mp3") )
                    .play()
                ,
                newFunction( ()=>getAudio("backgroundSound")._element.audio.loop = true )
                    .call()
                ,
                newTimer("stopLoop", 10)
                    .settings.callback(
                        getCanvas("container")
                            .test.printed()
                            .success( getTimer("stopLoop").start() )
                            .failure( getAudio("backgroundSound").stop() )
                    )
                    .start()
            ];
        case "Clock":
            let dot1 = document.createElement("DIV");
            dot1.style.position = "absolute";
            dot1.style.top = "30%";
            dot1.style.left = "49%";
            let dot2 = document.createElement("DIV");
            dot2.style.position = "absolute";
            dot2.style.top = "30%";
            dot2.style.left = "51%";
            let currentLevel = Number(row.Level);
            let itvl;
            let tmt;
            return [
                newAudio("sfx1", row.Pic1.replace("png","mp3")),
                newAudio("sfx2", row.Pic2.replace("png","mp3")),
                newAudio("sfx3", row.Pic3.replace("png","mp3")),
                newAudio("sfx4", row.Pic4.replace("png","mp3")),
                newAudio("sfx5", row.Pic5.replace("png","mp3")),
                newAudio("sfx6", row.Pic6.replace("png","mp3")),
                newAudio("sfx7", row.Pic7.replace("png","mp3")),
                newAudio("sfx8", row.Pic8.replace("png","mp3")),
                newAudio("sfx9", row.Pic9.replace("png","mp3")),
                newAudio("sfx10", row.Pic10.replace("png","mp3"))
                ,
                getCanvas("wheel")
                    .settings.callbackWheel( l=>{
                        if (itvl)
                            clearInterval(itvl);
                        if (tmt)
                            clearTimeout(tmt);
                        let lvl = currentLevel;
                        getAudio("sfx"+Number(10-currentLevel)).stop()._runPromises();
                        currentLevel = Number(l);
                        getAudio("sfx"+Number(10-currentLevel)).play()._runPromises();
                        dot1.className = "sfx"+Number(currentLevel+1);
                        dot2.className = "sfx"+Number(currentLevel+1);
                        let container = getCanvas("container");
                        if (container && container._element && container._element.jQueryElement)
                            container._element.jQueryElement.append(dot1);
                        tmt = setTimeout( ()=>{
                            let currentContainer = getCanvas("container");
                            if (currentContainer && currentContainer._element && container && container._element && currentContainer._element == container._element)
                                currentContainer._element.jQueryElement.append(dot2)
                        }, 500 );
                        itvl = setInterval( ()=> {
                            let currentContainer = getCanvas("container");
                            if (currentContainer && currentContainer._element && container && container._element && currentContainer._element == container._element){
                                if (lvl==currentLevel) {
                                    getAudio("sfx"+Number(10-currentLevel)).play()._runPromises();
                                    getCanvas("container")._element.jQueryElement.append(dot1);
                                    tmt = setTimeout( ()=>getCanvas("container")._element.jQueryElement.append(dot2) , 500 );
                                }
                            }
                            else
                                clearInterval(itvl);
                        },2000);
                    })
            ];
        default:
            return [];
    }
}